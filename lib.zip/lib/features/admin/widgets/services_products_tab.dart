import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:structure_mobile/core/providers/auth_provider.dart';
import 'package:structure_mobile/features/admin/models/service_product_model.dart';
import 'package:structure_mobile/features/admin/providers/dashboard_provider.dart';
import 'package:structure_mobile/features/admin/widgets/service_product_form_screen.dart';
import 'package:structure_mobile/themes/app_theme.dart';

class ServicesProductsTab extends StatefulWidget {
  const ServicesProductsTab({super.key});

  @override
  State<ServicesProductsTab> createState() => _ServicesProductsTabState();
}

class _ServicesProductsTabState extends State<ServicesProductsTab> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadServicesProducts();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Méthode pour charger les services/produits
  Future<void> _loadServicesProducts() async {
    final auth = context.read<AuthProvider>();
    final structureId = auth.user?.structureId;
    if (structureId != null) {
      context.read<DashboardProvider>().loadServices(structureId);
    }
  }

  // Ajouter un nouveau service/produit
  void _addNewServiceProduct() async {
    final auth = context.read<AuthProvider>();
    final provider = context.read<DashboardProvider>();
    
    final result = await Navigator.push<ServiceProduct?>(
      context,
      MaterialPageRoute(
        builder: (context) => ServiceProductFormScreen(
          onSave: (newService) async {
            final success = await provider.createService(newService);
            if (success && mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Service/produit enregistré avec succès'),
                  backgroundColor: Colors.green,
                ),
              );
            }
          },
          structureId: auth.user?.structureId ?? '',
          structureName: 'Ma Structure', 
        ),
      ),
    );
    
    if (result != null && mounted) {
      _loadServicesProducts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DashboardProvider>(
      builder: (context, provider, _) {
        final query = _searchController.text.toLowerCase();
        final filteredServices = provider.services.where((service) {
          if (query.isEmpty) return true;
          return service.name.toLowerCase().contains(query) ||
                 service.description.toLowerCase().contains(query);
        }).toList();

        return Scaffold(
          body: provider.isLoading
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    // Barre de recherche
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Rechercher un service ou produit...',
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {});
                        },
                      ),
                    ),

                    // Liste des services/produits
                    Expanded(
                      child: RefreshIndicator(
                        onRefresh: _loadServicesProducts,
                        child: filteredServices.isEmpty
                            ? ListView(
                                children: const [
                                  SizedBox(height: 100),
                                  Center(child: Text('Aucun service trouvé')),
                                ],
                              )
                            : ListView.builder(
                                itemCount: filteredServices.length,
                                itemBuilder: (context, index) {
                                  final service = filteredServices[index];
                                  return _buildServiceProductCard(context, service);
                                },
                              ),
                      ),
                    ),
                  ],
                ),
          floatingActionButton: FloatingActionButton(
            onPressed: _addNewServiceProduct,
            backgroundColor: AppTheme.primaryColor,
            child: const Icon(Icons.add, color: Colors.white),
          ),
        );
      },
    );
  }

  Widget _buildServiceProductCard(BuildContext context, ServiceProduct service) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: AppTheme.primaryColor,
          child: Icon(Icons.medical_services, color: Colors.white),
        ),
        title: Text(
          service.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service.description),
            const SizedBox(height: 4.0),
            Text(
              'XAF ${service.price.toStringAsFixed(0)}',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blueGrey),
              onPressed: () {
                // TODO: Implémenter la modification
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () {
                // TODO: Implémenter la suppression
              },
            ),
          ],
        ),
      ),
    );
  }
}
